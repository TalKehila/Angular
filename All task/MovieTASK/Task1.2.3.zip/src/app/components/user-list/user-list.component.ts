import { Component, Input } from '@angular/core';
import User from 'src/app/Model/User.Model';



@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent {
  users: User[]=[
    new User("username1","password1","David","david@Gee.com"),
    new User("username2","password2","SIHMON","SHIMNO@DSAAD"),
    new User("username3","password3","Ran","Ran@aaaa@d"),
    
  ]

  DeleteUser(user: User)
  {
   this.users = this.users.filter(u => u != user)
  }

UpdateUser(user: User)
{
const copy = this.users
const existUser = this.users.find(u => u.username === user.username)
if(existUser){
existUser.password = user.password;
existUser.email =user.email ;
existUser.username = user.username;
existUser.firstName=user.firstName;
console.log(existUser)
  }
}
 
  DuplicateUser(user: User,email:string ,firstName:string,password:string,username:string)
  {
    this.users.push(new User(user.password,user.username, user.firstName,user.email));

  }
}
 
