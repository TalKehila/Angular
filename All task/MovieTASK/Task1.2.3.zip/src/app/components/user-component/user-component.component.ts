import { Component, EventEmitter, Input, Output } from '@angular/core';
import User from 'src/app/Model/User.Model';
import { UserListComponent } from '../user-list/user-list.component';

@Component({
  selector: 'app-user-component',
  templateUrl: './user-component.component.html',
  styleUrls: ['./user-component.component.css']
})

export class UserComponentComponent {
  @Input() myuser: User = new User();
  @Output() delete = new EventEmitter<any>();
  @Output() duplicate = new EventEmitter<any>();

deleteme()
  {
    this.delete.emit(this.myuser)
  }

  duplicateme()
  {
    this.duplicate.emit(this.myuser)
  }

  update(firstName: string, username: string, password: string, email: string) {
    this.myuser.firstName=firstName;
    this.myuser.username = username;
    this.myuser.password = password;
    this.myuser.email = email;
    }
}
