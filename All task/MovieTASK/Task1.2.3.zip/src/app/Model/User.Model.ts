class User 
{
    //id:number;
    username:string;
    password:string;
    firstName:string;
    email:string;
    
    constructor(username:string="",password:string="",firstName:string="",email:string="")
    {    
        // id:number=0,
         //this.id=id;
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.email = email;
    }
}
export default User